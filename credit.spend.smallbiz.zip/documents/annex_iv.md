# EU AI Act — Annex IV Technical Documentation — Small-business card spend

*11 of 15 sections filled; 47 citation(s); digest `sha256:63a216ffe297305d`*

## Identity and ownership

| | |
|---|---|
| URN | `maya://model/credit.spend.smallbiz` |
| Name | Small-business card spend |
| Model class | credit.spend.linear |
| Domain | credit |
| Owner | person/j.okafor |
| Legal entity | LE-UK-01 |
| Declared purpose | expected 12-month card spend at renewal |
| Origin | internal |
| Record state | **amending** |

## Classification

| | |
|---|---|
| Version | `1.0.0` |
| Trainability class | **T2** |
| Parameter kind | `estimated_coefficients` |
| Fit procedure | `estimate` |
| Deterministic | True |
| Manifest digest | `sha256:35afb256c657befa8a1a3a0f4…` |
| Artifact digest | *none recorded — this version is descriptor-only* |

The class is **derived** from how the parameter object is inhabited (`estimated_coefficients` obtained by `estimate`), not declared. It determines which evidence is appropriate here: asking a T0 model for a training set is a type error, not a gap.

## Risk tier and required controls

| | |
|---|---|
| Tier | **2** |
| Materiality | material |
| Complexity | simple |
| Ruleset version | `2026.09.1` |

**Derivation.** materiality=material (exposure 2,000,000,000 in band 'material', purpose 'regulatory_capital'); complexity=simple (class T2); tau(material,simple)=Tier 2 under ruleset 2026.09.1

**Controls required at this tier.**

- independent_validation
- biennial_review
- quarterly_monitoring
- delegated_approval
- full_documentation

## Methodology and interfaces

**Inputs**

| Field | Type | Range |
|---|---|---|
| `turnover` | numeric | – |
| `tenure_years` | numeric | – |

**Outputs**

| Field | Type | Range |
|---|---|---|
| `annual_spend` | numeric | – |

Input schemas are contravariant and output schemas covariant, so a replacement version must accept everything this one accepts and promise everything it promises, or the alias move is refused.

## Assumptions and limitations

**Assumptions** — the model's guarantees hold only within these. Outside them the guarantee is void, and the execution engine refuses rather than extrapolating.

- `turnover` between 50 and 2000
- `tenure_years` between 0 and 60

**Guarantees** — what the model promises when its assumptions hold.

- `annual_spend` between 0 and None

## Data and features

The version is pinned to exact feature view versions. Serving reads these namespaces and no others; publishing a later view version does not move what this model is served.

| Feature view | Pinned version | Serving namespace |
|---|---|---|
| `sb_spend` | v1 | `features/borrower_id/sb_spend/v1` |

Contract digest: `sha256:52f35648164bad3b978242cd0…`

## Validation

**This section is required and could not be filled.**

Nothing in the register supports a `validation` section for this model yet. That is a statement about the model's evidence, not about this document.

## Open findings

No findings are open against this model.

## Ongoing monitoring

**This section is required and could not be filled.**

Nothing in the register supports a `monitoring` section for this model yet. That is a statement about the model's evidence, not about this document.

## Post-model adjustments

**This section is required and could not be filled.**

Nothing in the register supports a `overlays` section for this model yet. That is a statement about the model's evidence, not about this document.

## Supervisory regimes

Each supervisor is evaluated in its own vocabulary rather than against a merged checklist, because regimes disagree about what words mean and flattening them is how a scope determination becomes indefensible.

| Regime | Authority | Obligations met | |
|---|---|---|---|
| EU AI Act — high-risk and generative obligations | European Union | 2/5 | **not satisfied** |
| SR 26-2 / OCC — US model risk management | Federal Reserve, OCC, FDIC | 2/7 | **not satisfied** |
| PRA SS1/23 — UK model risk management principles | Bank of England, Prudential Regulation Authority | 3/5 | **not satisfied** |

**EU AI Act — high-risk and generative obligations — outstanding**

- high-risk systems are under human oversight *(EU AI Act Art. 14)*
- high-risk systems keep technical documentation *(EU AI Act Art. 11, Annex IV)*
- high-risk systems declare accuracy and robustness *(EU AI Act Art. 15)*

**SR 26-2 / OCC — US model risk management — outstanding**

- an in-scope model receives effective challenge *(SR 26-2 §IV — validation)*
- validation is independent of development *(SR 26-2 §IV)*
- an in-scope model is monitored on an ongoing basis *(SR 26-2 §IV — ongoing monitoring)*
- an in-scope model is documented *(SR 26-2 §V — documentation)*
- material models receive outcomes analysis *(SR 26-2 §IV)*

**PRA SS1/23 — UK model risk management principles — outstanding**

- validation is proportionate to materiality *(SS1/23 Principle 4)*
- high-materiality models get independent review *(SS1/23 Principle 4)*

## Approval and attestation

| | |
|---|---|
| Record state | **amending** |
| Meaning | an amendment is open; the record is changeable again |
| Open to change | True |

The record is attested and therefore immutable. Changing it requires an amendment, which must itself be attested.

**Amendments**

| Ref | Reason | Status |
|---|---|---|
| AMD-001 | add a sector index as a third regressor | attested |
| AMD-002 | add a sector index to the champion | open |

## Documents on file

**This section is required and could not be filled.**

Nothing in the register supports a `attachments` section for this model yet. That is a statement about the model's evidence, not about this document.

## Use and entitlement

A consumer holds only a URN. Artifact location, schemas, operating boundary and policy are resolved at the moment of use into a signed, expiring warrant.

| Principal | Approved use | Environment | |
|---|---|---|---|
| person/d.raman | model_development | prod | active |
| person/d.raman | model_development | prod | active |
| svc/renewals | renewal_limit_decision | prod | active |
| svc/renewals | renewal_limit_decision | prod | active |

## Provenance

Every statement in this document is drawn from an append-only, hash-chained record. The chain is currently **valid**, and 47 entries in it are about this model.

| Evidence kind | Entries about this model |
|---|---|
| `alias_moved` | 2 |
| `amendment_attested` | 1 |
| `amendment_opened` | 2 |
| `attestation_attested` | 2 |
| `attestation_opened` | 2 |
| `attestation_signed` | 4 |
| `document_compiled` | 1 |
| `feature_contract_bound` | 1 |
| `model_amend` | 2 |
| `model_approve` | 2 |
| `model_attest` | 2 |
| `model_registered` | 1 |
| `model_submit` | 2 |
| `parameter_set_approved` | 1 |
| `parameter_set_fitted` | 2 |
| `parameter_set_recorded` | 3 |
| `tier_assigned` | 1 |
| `version_approval_approved` | 2 |
| `version_approval_opened` | 2 |
| `version_approval_signed` | 4 |
| `version_approved` | 2 |
| `version_created` | 2 |
| `warrant_issued` | 4 |
