# Model Card — Small-business card spend

*4 of 7 sections filled; 5 citation(s); digest `sha256:e79b6859890ba750`*

## Identity and ownership

| | |
|---|---|
| URN | `maya://model/credit.spend.smallbiz` |
| Name | Small-business card spend |
| Model class | credit.spend.linear |
| Domain | credit |
| Owner | person/j.okafor |
| Legal entity | LE-UK-01 |
| Declared purpose | expected 12-month card spend at renewal |
| Origin | internal |
| Record state | **amending** |

## Classification

| | |
|---|---|
| Version | `1.0.0` |
| Trainability class | **T2** |
| Parameter kind | `estimated_coefficients` |
| Fit procedure | `estimate` |
| Deterministic | True |
| Manifest digest | `sha256:35afb256c657befa8a1a3a0f4…` |
| Artifact digest | *none recorded — this version is descriptor-only* |

The class is **derived** from how the parameter object is inhabited (`estimated_coefficients` obtained by `estimate`), not declared. It determines which evidence is appropriate here: asking a T0 model for a training set is a type error, not a gap.

## Assumptions and limitations

**Assumptions** — the model's guarantees hold only within these. Outside them the guarantee is void, and the execution engine refuses rather than extrapolating.

- `turnover` between 50 and 2000
- `tenure_years` between 0 and 60

**Guarantees** — what the model promises when its assumptions hold.

- `annual_spend` between 0 and None

## Validation

*Not applicable to this model, or not yet recorded.*

Nothing in the register supports a `validation` section for this model yet. That is a statement about the model's evidence, not about this document.

## Open findings

No findings are open against this model.

## Ongoing monitoring

*Not applicable to this model, or not yet recorded.*

Nothing in the register supports a `monitoring` section for this model yet. That is a statement about the model's evidence, not about this document.

## Post-model adjustments

*Not applicable to this model, or not yet recorded.*

Nothing in the register supports a `overlays` section for this model yet. That is a statement about the model's evidence, not about this document.
