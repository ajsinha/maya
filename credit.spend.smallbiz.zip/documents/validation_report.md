# Validation Report — Small-business card spend

*7 of 11 sections filled; 47 citation(s); digest `sha256:378731ae3681246b`*

## Identity and ownership

| | |
|---|---|
| URN | `maya://model/credit.spend.smallbiz` |
| Name | Small-business card spend |
| Model class | credit.spend.linear |
| Domain | credit |
| Owner | person/j.okafor |
| Legal entity | LE-UK-01 |
| Declared purpose | expected 12-month card spend at renewal |
| Origin | internal |
| Record state | **amending** |

## Classification

| | |
|---|---|
| Version | `1.0.0` |
| Trainability class | **T2** |
| Parameter kind | `estimated_coefficients` |
| Fit procedure | `estimate` |
| Deterministic | True |
| Manifest digest | `sha256:35afb256c657befa8a1a3a0f4…` |
| Artifact digest | *none recorded — this version is descriptor-only* |

The class is **derived** from how the parameter object is inhabited (`estimated_coefficients` obtained by `estimate`), not declared. It determines which evidence is appropriate here: asking a T0 model for a training set is a type error, not a gap.

## Risk tier and required controls

| | |
|---|---|
| Tier | **2** |
| Materiality | material |
| Complexity | simple |
| Ruleset version | `2026.09.1` |

**Derivation.** materiality=material (exposure 2,000,000,000 in band 'material', purpose 'regulatory_capital'); complexity=simple (class T2); tau(material,simple)=Tier 2 under ruleset 2026.09.1

**Controls required at this tier.**

- independent_validation
- biennial_review
- quarterly_monitoring
- delegated_approval
- full_documentation

## Validation

**This section is required and could not be filled.**

Nothing in the register supports a `validation` section for this model yet. That is a statement about the model's evidence, not about this document.

## Open findings

No findings are open against this model.

## Data and features

The version is pinned to exact feature view versions. Serving reads these namespaces and no others; publishing a later view version does not move what this model is served.

| Feature view | Pinned version | Serving namespace |
|---|---|---|
| `sb_spend` | v1 | `features/borrower_id/sb_spend/v1` |

Contract digest: `sha256:f57ef5c6449571795d5c60958…`

## Ongoing monitoring

*Not applicable to this model, or not yet recorded.*

Nothing in the register supports a `monitoring` section for this model yet. That is a statement about the model's evidence, not about this document.

## Post-model adjustments

*Not applicable to this model, or not yet recorded.*

Nothing in the register supports a `overlays` section for this model yet. That is a statement about the model's evidence, not about this document.

## Approval and attestation

| | |
|---|---|
| Record state | **amending** |
| Meaning | an amendment is open; the record is changeable again |
| Open to change | True |

The record is attested and therefore immutable. Changing it requires an amendment, which must itself be attested.

**Amendments**

| Ref | Reason | Status |
|---|---|---|
| AMD-001 | add a sector index as a third regressor | attested |
| AMD-002 | add a sector index to the champion | open |

## Documents on file

*Not applicable to this model, or not yet recorded.*

Nothing in the register supports a `attachments` section for this model yet. That is a statement about the model's evidence, not about this document.

## Provenance

Every statement in this document is drawn from an append-only, hash-chained record. The chain is currently **valid**, and 47 entries in it are about this model.

| Evidence kind | Entries about this model |
|---|---|
| `alias_moved` | 2 |
| `amendment_attested` | 1 |
| `amendment_opened` | 2 |
| `attestation_attested` | 2 |
| `attestation_opened` | 2 |
| `attestation_signed` | 4 |
| `document_compiled` | 1 |
| `feature_contract_bound` | 1 |
| `model_amend` | 2 |
| `model_approve` | 2 |
| `model_attest` | 2 |
| `model_registered` | 1 |
| `model_submit` | 2 |
| `parameter_set_approved` | 1 |
| `parameter_set_fitted` | 2 |
| `parameter_set_recorded` | 3 |
| `tier_assigned` | 1 |
| `version_approval_approved` | 2 |
| `version_approval_opened` | 2 |
| `version_approval_signed` | 4 |
| `version_approved` | 2 |
| `version_created` | 2 |
| `warrant_issued` | 4 |
