# Export pack — Small-business card spend

`maya://model/credit.spend.smallbiz`

This is a self-contained record of one model, cut from MAYA at a stated moment.
Everything in it was gathered from the register and the evidence chain; nothing
was written for this pack.

## How to verify it

`manifest.json` lists every file with its SHA-256. Re-hash each one and compare.

The manifest also carries a **content digest** over every file except the
manifest itself. That is the number to compare between two packs: it is the same
for two packs of the same state even though they were cut at different moments,
so *"has anything changed since the last pack?"* is one comparison rather than a
diff of a hundred files.

`chain.head_seq` and `chain.head_hash` record where the evidence chain stood.
A later pack with a higher `head_seq` means the record moved; the same head means
it did not.

## What is here

Read `gaps.md` first. It lists everything this pack could **not** include and
why — an absence is recorded rather than omitted, because a pack that quietly
dropped what it could not reach reads as complete.

Then `documents/` for the compiled documents, `evidence/chain.json` for what
supports them, and the remaining JSON files for the register state each document
was compiled from.

## What is deliberately not here

Nodes that reference **personal data** carry no payload rather than the
data, in the pack exactly as in the platform. Resolving it here would put
personal data into a file an erasure request cannot reach, which would defeat the
control rather than export it.
