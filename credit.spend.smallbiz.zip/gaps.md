# Gaps

What this pack could not include, and why. An absence is recorded rather than omitted: a pack that silently dropped what it could not reach would read as complete, and a reader would have no way to tell a thin model from a thin export.

| What | Why |
|---|---|
| `documentation/model Small-business card spend` | nothing is filed here; expected the methodology, and the literature the approach comes from |
| `documentation/featureset_version sb_spend_v1 @ v1` | nothing is filed here; expected the data dictionary, and the source-system agreement |
| `documentation/feature annual_spend` | nothing is filed here; expected the business definition |
| `documentation/feature tenure_years` | nothing is filed here; expected the business definition |
| `documentation/feature turnover` | nothing is filed here; expected the business definition |
| `documentation/parameter_set parameters ols_statsmodels` | nothing is filed here; expected the training record, and any note explaining this fit |
| `documentation/featureset_version sb_spend_v1 @ v1` | nothing is filed here; expected the data dictionary, and the source-system agreement |
| `documentation/feature annual_spend` | nothing is filed here; expected the business definition |
| `documentation/feature tenure_years` | nothing is filed here; expected the business definition |
| `documentation/feature turnover` | nothing is filed here; expected the business definition |
| `documentation/parameter_set parameters ols_2026_04` | nothing is filed here; expected the training record, and any note explaining this fit |
| `documentation/featureset_version sb_spend_v1 @ v1` | nothing is filed here; expected the data dictionary, and the source-system agreement |
| `documentation/feature annual_spend` | nothing is filed here; expected the business definition |
| `documentation/feature tenure_years` | nothing is filed here; expected the business definition |
| `documentation/feature turnover` | nothing is filed here; expected the business definition |
| `documentation/model_version version 1.1.0` | nothing is filed here; expected the specification of this kernel |
| `documents/model_development_document.md § validation` | a required section had no evidence to fill it |
| `documents/model_development_document.md § monitoring` | a required section had no evidence to fill it |
| `documents/model_development_document.md § overlays` | a required section had no evidence to fill it |
| `documents/model_development_document.md § attachments` | a required section had no evidence to fill it |
| `documents/validation_report.md § validation` | a required section had no evidence to fill it |
| `documents/annex_iv.md § validation` | a required section had no evidence to fill it |
| `documents/annex_iv.md § monitoring` | a required section had no evidence to fill it |
| `documents/annex_iv.md § overlays` | a required section had no evidence to fill it |
| `documents/annex_iv.md § attachments` | a required section had no evidence to fill it |
